package com.company;

public interface Shape {

    void draw();
}
