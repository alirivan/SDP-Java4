package com.company;

public class GoldCard extends CardType {

    public GoldCard() {
        setCreditLimit();
    }

    @Override
    public void setCreditLimit() {
        CreditLimit = 200000;
    }
}
