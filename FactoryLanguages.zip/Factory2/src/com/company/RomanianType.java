package com.company;

public class RomanianType extends LanguageType{

    public RomanianType() {
        setLanguageName();
    }

    @Override
    public void setLanguageName() {
        LanguageName = "French, Spanish, Italian, Romanian";
    }
}
