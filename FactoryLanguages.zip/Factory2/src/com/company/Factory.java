package com.company;

public class Factory {

    public static LanguageType getLanguage(String type) {
        switch (type) {
            case "Germanic":
                return new GermanicType();

            case "Romanian":
                return new RomanianType();

            case "Slavic":
                return new SlavicType();

            default:
                return null;
        }
    }
}
