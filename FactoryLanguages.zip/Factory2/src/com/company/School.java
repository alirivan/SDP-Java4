package com.company;
import java.util.Scanner;

public class School {
    public static void main(String[] args) {

        System.out.println("Below you see list of Countries");
        System.out.println("You should choose your favorite Country from the list (Number)");
        System.out.println("-------------------------------");
        System.out.println("1. Germany");
        System.out.println("2. France");
        System.out.println("3. Czechia");
        System.out.println("-------------------------------");

        String languageType = "";
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your favourite Country: ");

        int country = sc.nextInt();

        if (country == 1) {
            languageType = "Germanic";
        }

        else if (country == 2) {
            languageType = "Romanian";
        }

        else {
            languageType = "Slavic";
        }

        LanguageType MyLanguage = Factory.getLanguage(languageType);
        System.out.println(MyLanguage);
    }
}
