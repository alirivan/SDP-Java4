package com.company;
import java.util.Arrays;

public abstract class LanguageType {

    protected String LanguageName;
    public abstract void setLanguageName();

    @Override
    public String toString() {
        return "Your language family is " + this.getClass().getSimpleName() + " and languages for you are " + LanguageName;
    }
}
