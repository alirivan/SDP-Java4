package com.company;

public class SlavicType extends LanguageType{

    public SlavicType(){
        setLanguageName();
    }

    @Override
    public void setLanguageName() {
        LanguageName = "Russian, Ukrainian, Belorussian, Polish, Czech, Slovak, Bulgarian, Macedonian, Serbian, Croatian, Slovenian, Bosnian";
    }
}
