package com.company;

public class GermanicType extends LanguageType{

    public GermanicType() {
        setLanguageName();
    }

    @Override
    public void setLanguageName() {
        LanguageName = "English, German, Deutsch, Norwegian, Swedish, Danish, Icelandic";
    }
}
